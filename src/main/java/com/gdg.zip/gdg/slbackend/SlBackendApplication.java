package com.gdg.slbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SlBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(SlBackendApplication.class, args);
    }

}
