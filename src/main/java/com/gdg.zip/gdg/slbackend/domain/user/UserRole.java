package com.gdg.slbackend.domain.user;

public enum UserRole {
    SYSTEM_ADMIN,
    USER
}
